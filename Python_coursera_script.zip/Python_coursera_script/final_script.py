#!usr\bin\python

import sys
import Bio


dna_seq_file= sys.argv[1]

### The program to calculate various sequence stats and repeats of given repeat length. 
### Call the program using python final_script.py <input FASTA file stored in same directory>

# function to count total no of records in the file

def total_sequence_records(dna_seq_file):
	from Bio import SeqIO
	records = list(SeqIO.parse(dna_seq_file, "fasta"))
	#print("Found %i records" % len(records))

	return len(records)


# funtion to calculate lengths of sequences in the file and the longest as well as shortest. It will check if there are more than one longest and shortest sequence	
def sequence_stats(dna_seq_file):
	record_data={}
	vals=[]
	ids=[]
	stats = open("SEQUENCE_STATS.out","w")
	from Bio import SeqIO
	for seq_record in SeqIO.parse(dna_seq_file, "fasta"):
		record_data.update({seq_record.id : len(seq_record.seq)})
		#print(seq_record.id,len(seq_record.seq))
		#print(list(record_data.values()))
		vals.extend(record_data.values())
		ids.extend(record_data.keys())
	maxVal = max(vals)
	minVal = min(vals)

	# Find out no of longest and shortest sequences
	#maxVal, minVal = max(vals), min(vals)
	minVals, maxVals = [], []
	for k in record_data. keys():
		#print(k,record_data[k])
		if record_data[k] == maxVal:
			maxVals.append((k, maxVal))
		elif record_data[k] == minVal:
			minVals.append((k, minVal))
        
	stats.write("The longest sequence or sequences are")
	stats.write(str(maxVals))
	stats.write("\n\n")
	stats.write("The shortest sequence or sequences are")
	stats.write(str(minVals))
	stats.close()
	return 


# Function to calculate ORFs for all sequences for a given reading frame

def calculate_ORFstats(file,frame):
	
	ORFfile = open("ORFStats.out","w")
	ORFfile.write("For reading frame ")
	ORFfile.write(str(frame))
	ORFfile.write("\n")
	start =['ATG']
	stop = ['TAA','TAG','TGA']
	seqdata={}
	seqorf={}
	seqorfpos={}
	import sys

	from Bio import SeqIO
	for record in SeqIO.parse(file, "fasta"):
		seqlen = len(record.seq)
		seqdata.update({record.id:record.seq})
		maxorf_pos=0
		maxorf_len=0
		
		startsignal =0
		for i in range(frame,seqlen,3):
			orf=[]
			
			if str(record.seq[i:i+3]) in start:
				ORFfile.write("Identifier: ")
				ORFfile.write(record.id)
				ORFfile.write("\n\n")
				startsignal =1
				stopsignal=0
				orf.extend(record.seq[i:i+3])
				orf_startpos= i+1
				if startsignal == 1:
					for j in range(i+3,seqlen,3):
						if record.seq[j:j+3] not in stop:
							orf.extend(record.seq[j:j+3])
						elif record.seq[j:j+3]  in stop:
							orf.extend(record.seq[j:j+3])
							orf_endpos = j+1
							#startsignal =0
							stopsignal=1
							#ORFfile.write("ORF Sequence\n")
							#ORFfile.write(str(orf))
							ORFfile.write("ORF length ")
							ORFfile.write(str(len(orf)))
							ORFfile.write("\n")
							ORFfile.write("\nORF start position\t")
							ORFfile.write(str(orf_startpos))
							ORFfile.write("\n")
							if len(orf) > maxorf_len:
								
								maxorf_len = len(orf)
								maxorf_pos= orf_startpos
								seqorf.update({record.id: maxorf_len})
								seqorfpos.update({record.id: maxorf_pos})
							break
					 
					if stopsignal==0 :
							#print("hi")
						#startsignal =0
						ORFfile.write(" No valid ORF")
						ORFfile.write("\n")
						break
						
					 
				#break			
		 		
		if startsignal == 0:
			ORFfile.write(record.id)
			ORFfile.write("\nNo valid ORF\n")
	## print longest orf in file
	
	maxx=max(seqorf.values())
	#print(maxx)
	keys = [x for x,y in seqorf.items() if y ==maxx] 
	for a in range(len(keys)):
		ORFfile.write("Sequence id is   ")
		ORFfile.write(str(keys[a]))
		ORFfile.write("\n")
		ORFfile.write("Longest Sequence length is    ")
		ORFfile.write(str(maxx))
		ORFfile.write("\n")
		ORFfile.write("Sequence position is   ")
		ORFfile.write(str(seqorfpos[keys[a]]))
		ORFfile.write("\n")
	ORFfile.close()
	#print(longestorf)
	return					
		
def calculate_repeats(file,repeatlength):
	from Bio import SeqIO
	record_data={}
	FINAL_COUNTS={}
	final_flag=0
	repeatfile = open("REPEATS.out","w")
	for record in SeqIO.parse(file, "fasta"):
		#record_data.update({record.id : record.seq})
		seqlen = len(record.seq)
		#print (seqlen)
		kmer = []
		kmerids =[]
		k=0
		for i in range(0,seqlen-repeatlength+1):
			#print (record.seq[0:5])
			sub_i = record.seq[i:repeatlength+i] 
			kmer.append([str(sub_i)])
			kmerids.append(i);
			#print(kmer)
			#print("-----------------------------")
			#for j in range(i+1,len(record.seq)-repeatlength+1):
			#	sub_j1 = record.seq[j:repeatlength+j]
			m=0
			for j in range(0,len(record.seq)-repeatlength+1):
				if i != j :
					sub_j= record.seq[j:repeatlength+j]
					#kmer.append([str(sub_j)])
					#print(kmer)
						
				#all_subseqs.append(sub)
		
		#print(kmer)
		#print(kmerids)
		#print("END")
		flag =1
		repeatdata={}
		
		for a in range(len(kmer)):
			newval=0
			if kmer.count(kmer[a])> 1:
				tempval=()
				repeatfile.write(record.id)
				repeatfile.write("\n")
				flag =0
				#print(kmer[a],kmer.count(kmer[a]))
				tempval = str(kmer[a])
				repeatfile.write(tempval)
				repeatfile.write("\t")
				repeatfile.write(str(kmer.count(kmer[a])))
				repeatfile.write("\n")
				repeatdata.update({tempval:kmer.count(kmer[a])})
				'''
				if tempval  in FINAL_COUNTS.keys():
					newval = FINAL_COUNTS[tempval]+(repeatdata[tempval])
					print(FINAL_COUNTS[tempval],repeatdata[tempval])
					print(newval)
					FINAL_COUNTS.update({tempval:newval})
				else:
					FINAL_COUNTS.update({tempval:kmer.count(tempval)})
				'''
		#print(repeatdata.keys(),repeatdata.values())
		for key in repeatdata:
			if key in FINAL_COUNTS.keys():
				newval = FINAL_COUNTS[key]+(repeatdata[key])
				FINAL_COUNTS.update({key:newval})
			else:
				FINAL_COUNTS.update({key:repeatdata[key]})
		if flag == 1:
			repeatfile.write(record.id)
			repeatfile.write("\nNo repeats found\n")
	if(FINAL_COUNTS.values()):
		maxx=max(FINAL_COUNTS.values())
	else:
		maxx = 0
	repeatfile.write("\nFINAL VALUES ############\n")
	#repeatfile.write(str(FINAL_COUNTS.keys()))
	#repeatfile.write("\t")
	#repeatfile.write(str(FINAL_COUNTS.values()))
	#repeatfile.write("\n")
	if(maxx == 0):
		repeatfile.write("\nNo repeats found\n")
		repeatfile.close()
	else:
	#print(maxx)
		keys = [x for x,y in FINAL_COUNTS.items() if y ==maxx] 
		for a in range(len(keys)):
			repeatfile.write("Pattern is   ")
			repeatfile.write("\n")
			repeatfile.write((keys[a]))
			repeatfile.write("\n")
			repeatfile.write("No of times it occurs  ")
			repeatfile.write("\n")
			repeatfile.write(str(maxx))
			repeatfile.write("\n")
		#print("Sequence position is" , seqorfpos[keys[a]])	
		repeatfile.close()
	return


Total_records = total_sequence_records(dna_seq_file)
print("Found %i records" % Total_records)

sequence_stats(dna_seq_file) ## funtion to calculate lengths of sequences in the file and the longest as well as shortest. It will check if there are more than one longest and shortest sequence	

calculate_ORFstats(dna_seq_file,1) # Enter the first argument as filename and second argument as frame (1,2 or 3)


calculate_repeats(dna_seq_file,10) ### Enter the first argument as filename and second argument as repeat length