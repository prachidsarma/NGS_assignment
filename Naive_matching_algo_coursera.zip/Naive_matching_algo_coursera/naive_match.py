#!usr/python/bin
import re

def naive(p, t):
	occurrences = []
	for i in range(len(t) - len(p) + 1):  # loop over alignments
		match = True
		for j in range(len(p)):  # loop over characters
			if t[i+j] != p[j]:  # compare characters
				match = False
				break
		if match:
			occurrences.append(i)  # all chars matched; record
	return occurrences


def reverseComplement(s):
	complement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A', 'N': 'N'}
	t = ''
	for base in s:
		t = complement[base] + t
	return t
	

def readGenome(filename):
	genome = ''
	with open(filename, 'r') as f:
		for line in f:
			#ignore header line with genome information
			if not line[0] == '>':
				genome += line.rstrip()
	return genome
	

def readFastq(filename):
	sequences = []
	qualities = []
	with open(filename) as fh:
		while True:
			fh.readline()  # skip name line
			seq = fh.readline().rstrip()  # read base sequence
			fh.readline()  # skip placeholder line
			qual = fh.readline().rstrip() # base quality line
			if len(seq) == 0:
				break
			sequences.append(seq)
			qualities.append(qual)
	return sequences, qualities

def naive_with_rc(p,t):
	occurences=[]
	for i in range(len(t) - len(p) + 1):  # loop over alignments
		match = True
		match1 = True
		for j in range(len(p)):  # loop over characters
			if t[i+j] != p[j]:  # compare characters
				match = False
				break
		if match:
			occurences.append(i)  # all chars matched; record

		revseq = reverseComplement(p)
		for k in range(len(revseq)):  # loop over characters
			if t[i+k] != revseq[k]:  # compare characters
				match1 = False
				break
		if match1:
			
			occurences.append(i)  # all chars matched; record
		s = []
		for i in occurences:
			if i not in s:
				s.append(i)
	return s
#print(naive_with_rc('TTAA','AAAAGGTTAAAACGCGAAAGGTTAAAACCTGAAAATTAAACCT'))
#phix_genome = readGenome('phix.fa')
#occurrences = naive_with_rc('ATTA', phix_genome)
#print('offset of leftmost occurrence: %d' % min(occurrences))
#print('# occurrences: %d' % len(occurrences))

lambda_virus=readGenome('lambda_virus.fa')
pattern=(input("Print the pattern to search eg 'GATCAG'\n"))
validdna='ATGCN'
pattern=pattern.upper()
condition = all(i in validdna for i in pattern)
if(not condition):
	print("Enter a correct pattern with valid bases like A T C G or N\n")
	exit
else:


#pattern = 'GATCAG'
	occurrences = naive_with_rc(pattern, lambda_virus)
	print("Naive matching with reverese complement...\n")
	print('pattern searched is %s' % pattern)
	print('offset of leftmost occurrence: %d' % min(occurrences))
	print('# occurrences: %d' % len(occurrences))



